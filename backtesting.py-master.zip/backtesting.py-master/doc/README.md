Backtesting.py Documentation
============================
After installing documentation dependencies:

    pip install .[doc,test]

build HTML documentation by running:

    ./build.sh

When submitting pull requests that change example notebooks,
commit example _.py_ files too
(`build.sh` should tell you how to make them).
